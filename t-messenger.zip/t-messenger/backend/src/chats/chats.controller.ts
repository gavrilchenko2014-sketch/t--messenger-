import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { ChatsService } from './chats.service';
import { JwtAuthGuard } from '../common/jwt-auth.guard';
import { CurrentUser } from '../common/current-user.decorator';
import { GroupChatDto, PrivateChatDto } from './dto';

@Controller('chats')
@UseGuards(JwtAuthGuard)
export class ChatsController {
  constructor(private readonly chats: ChatsService) {}

  @Get()
  list(@CurrentUser() user: any) {
    return this.chats.list(user.id);
  }

  @Post('private')
  privateChat(@CurrentUser() user: any, @Body() dto: PrivateChatDto) {
    return this.chats.createPrivate(user.id, dto.userId);
  }

  @Post('group')
  group(@CurrentUser() user: any, @Body() dto: GroupChatDto) {
    return this.chats.createGroup(user.id, dto);
  }

  @Get(':id')
  one(@CurrentUser() user: any, @Param('id') id: string) {
    return this.chats.getOne(id, user.id);
  }
}
