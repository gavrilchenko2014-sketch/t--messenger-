import {
  ConnectedSocket,
  MessageBody,
  OnGatewayConnection,
  OnGatewayDisconnect,
  OnGatewayInit,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import { Logger } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Server, Socket } from 'socket.io';
import { UsersService } from '../users/users.service';
import { ChatsService } from '../chats/chats.service';
import { MessagesService } from '../messages/messages.service';
import { EventsHub } from './events.hub';

@WebSocketGateway({
  cors: { origin: true, credentials: true },
  transports: ['websocket', 'polling'],
})
export class ChatGateway
  implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect
{
  @WebSocketServer()
  server: Server;

  private readonly log = new Logger(ChatGateway.name);

  constructor(
    private readonly jwt: JwtService,
    private readonly users: UsersService,
    private readonly chats: ChatsService,
    private readonly messages: MessagesService,
    private readonly hub: EventsHub,
  ) {}

  afterInit(server: Server) {
    this.hub.setServer(server);
  }

  async handleConnection(client: Socket) {
    try {
      const token =
        (client.handshake.auth && client.handshake.auth.token) ||
        this.bearer(client.handshake.headers.authorization as string);
      if (!token) throw new Error('no token');
      const payload = this.jwt.verify(token);
      const userId = payload.sub as string;
      client.data.userId = userId;
      client.join(`user:${userId}`);
      await this.users.setOnline(userId, true);
      this.server.emit('user_online', { userId });
      this.log.log(`connected ${userId}`);
    } catch {
      client.disconnect(true);
    }
  }

  async handleDisconnect(client: Socket) {
    const userId = client.data.userId as string | undefined;
    if (!userId) return;
    await this.users.setOnline(userId, false);
    this.server.emit('user_offline', { userId, lastSeen: new Date() });
  }

  @SubscribeMessage('join_chat')
  async joinChat(@ConnectedSocket() client: Socket, @MessageBody() body: any) {
    const chatId = body?.chatId;
    await this.chats.assertMember(chatId, client.data.userId);
    client.join(`chat:${chatId}`);
    return { ok: true };
  }

  @SubscribeMessage('leave_chat')
  leaveChat(@ConnectedSocket() client: Socket, @MessageBody() body: any) {
    client.leave(`chat:${body?.chatId}`);
    return { ok: true };
  }

  @SubscribeMessage('send_message')
  async sendMessage(@ConnectedSocket() client: Socket, @MessageBody() body: any) {
    const userId = client.data.userId as string;
    const msg = await this.messages.create(body.chatId, userId, {
      type: body.type,
      text: body.text,
      attachmentId: body.attachmentId,
    });
    const members = await this.messages.memberIds(body.chatId);
    for (const mid of members) {
      if (mid === userId) continue;
      const sockets = await this.server.in(`user:${mid}`).fetchSockets();
      if (sockets.length) {
        await this.messages.markDelivered(msg.id, mid);
      }
    }
    return msg;
  }

  @SubscribeMessage('typing_start')
  typingStart(@ConnectedSocket() client: Socket, @MessageBody() body: any) {
    this.hub.toChat(body.chatId, 'typing_start', {
      chatId: body.chatId,
      userId: client.data.userId,
    });
  }

  @SubscribeMessage('typing_stop')
  typingStop(@ConnectedSocket() client: Socket, @MessageBody() body: any) {
    this.hub.toChat(body.chatId, 'typing_stop', {
      chatId: body.chatId,
      userId: client.data.userId,
    });
  }

  @SubscribeMessage('call_offer')
  callOffer(@ConnectedSocket() client: Socket, @MessageBody() body: any) {
    this.hub.toChat(body.chatId, 'call_offer', { ...body, from: client.data.userId });
  }

  @SubscribeMessage('call_answer')
  callAnswer(@ConnectedSocket() client: Socket, @MessageBody() body: any) {
    this.hub.toChat(body.chatId, 'call_answer', { ...body, from: client.data.userId });
  }

  @SubscribeMessage('call_ice')
  callIce(@ConnectedSocket() client: Socket, @MessageBody() body: any) {
    this.hub.toChat(body.chatId, 'call_ice', { ...body, from: client.data.userId });
  }

  @SubscribeMessage('call_hangup')
  callHangup(@ConnectedSocket() client: Socket, @MessageBody() body: any) {
    this.hub.toChat(body.chatId, 'call_hangup', { ...body, from: client.data.userId });
  }

  private bearer(header?: string) {
    if (!header) return null;
    return header.startsWith('Bearer ') ? header.slice(7) : header;
  }
}
