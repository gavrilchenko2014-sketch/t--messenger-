import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:t_messenger/state/app_state.dart';
import 'package:t_messenger/theme/app_theme.dart';
import 'package:t_messenger/screens/splash_screen.dart';
import 'package:t_messenger/screens/auth/login_screen.dart';
import 'package:t_messenger/screens/shell_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const TMessengerApp());
}

class TMessengerApp extends StatelessWidget {
  const TMessengerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AppState()..bootstrap(),
      child: Consumer<AppState>(
        builder: (context, state, _) {
          return MaterialApp(
            title: 'T-Messenger',
            debugShowCheckedModeBanner: false,
            theme: AppTheme.dark,
            home: state.booting
                ? const SplashScreen()
                : state.isAuthed
                    ? const ShellScreen()
                    : const LoginScreen(),
          );
        },
      ),
    );
  }
}
