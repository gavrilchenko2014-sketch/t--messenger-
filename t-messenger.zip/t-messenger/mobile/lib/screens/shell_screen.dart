import 'package:flutter/material.dart';
import 'package:t_messenger/screens/chats/chats_screen.dart';
import 'package:t_messenger/screens/contacts/contacts_screen.dart';
import 'package:t_messenger/screens/settings/settings_screen.dart';
import 'package:t_messenger/theme/app_theme.dart';

class ShellScreen extends StatefulWidget {
  const ShellScreen({super.key});
  @override
  State<ShellScreen> createState() => _ShellScreenState();
}

class _ShellScreenState extends State<ShellScreen> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = const [ChatsScreen(), ContactsScreen(), SettingsScreen()];
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          border: Border(top: BorderSide(color: Color(0x22D4A574))),
        ),
        child: BottomNavigationBar(
          currentIndex: index,
          onTap: (i) => setState(() => index = i),
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.forum_outlined), label: 'Чаты'),
            BottomNavigationBarItem(icon: Icon(Icons.person_search_outlined), label: 'Контакты'),
            BottomNavigationBarItem(icon: Icon(Icons.tune_outlined), label: 'Настройки'),
          ],
        ),
      ),
      backgroundColor: AppColors.bg,
    );
  }
}
