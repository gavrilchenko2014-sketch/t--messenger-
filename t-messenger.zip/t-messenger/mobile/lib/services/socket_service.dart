import 'package:socket_io_client/socket_io_client.dart' as io;
import 'package:t_messenger/services/api_client.dart';

class SocketService {
  SocketService(this.api);
  final ApiClient api;
  io.Socket? socket;

  void connect({
    required void Function(dynamic) onNewMessage,
    required void Function(dynamic) onDelivered,
    required void Function(dynamic) onRead,
    required void Function(dynamic) onTypingStart,
    required void Function(dynamic) onTypingStop,
    required void Function(dynamic) onOnline,
    required void Function(dynamic) onOffline,
  }) {
    disconnect();
    if (api.token == null) return;
    socket = io.io(
      api.baseUrl,
      io.OptionBuilder()
          .setTransports(['websocket'])
          .enableForceNew()
          .setAuth({'token': api.token})
          .disableAutoConnect()
          .build(),
    );
    socket!.on('new_message', onNewMessage);
    socket!.on('message_delivered', onDelivered);
    socket!.on('message_read', onRead);
    socket!.on('typing_start', onTypingStart);
    socket!.on('typing_stop', onTypingStop);
    socket!.on('user_online', onOnline);
    socket!.on('user_offline', onOffline);
    socket!.connect();
  }

  void joinChat(String chatId) => socket?.emit('join_chat', {'chatId': chatId});
  void leaveChat(String chatId) => socket?.emit('leave_chat', {'chatId': chatId});
  void typing(String chatId, bool start) =>
      socket?.emit(start ? 'typing_start' : 'typing_stop', {'chatId': chatId});

  void sendMessage({
    required String chatId,
    String? text,
    String type = 'TEXT',
    String? attachmentId,
  }) {
    socket?.emit('send_message', {
      'chatId': chatId,
      'text': text,
      'type': type,
      'attachmentId': attachmentId,
    });
  }

  void disconnect() {
    socket?.dispose();
    socket = null;
  }
}
