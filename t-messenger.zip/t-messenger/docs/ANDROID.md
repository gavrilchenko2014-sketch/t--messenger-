# Android / Flutter notes

## Первый запуск платформенных файлов

В репозитории лежит исходник `lib/` и `pubspec.yaml`.
Перед первой сборкой сгенерируйте платформенные проекты:

```bash
cd mobile
flutter create . --project-name t_messenger --org com.tmessenger
flutter pub get
```

`flutter create .` не затрёт уже существующие файлы в `lib/`.

## Разрешения Android

В `android/app/src/main/AndroidManifest.xml` внутри `<manifest>`:

```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
<uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
```

Для Android 9 и ниже, если ходите на http://IP:3000 (без TLS), в `<application>`:

```xml
android:usesCleartextTraffic="true"
```

Иначе телефон откажется ходить на незашифрованный backend.

## applicationId

Ожидаемый id: `com.tmessenger.app`

При `flutter create --org com.tmessenger` получится `com.tmessenger.t_messenger`.
Это нормально. Для FCM используйте фактический package name из
`android/app/build.gradle`.

## Сборка APK

```bash
flutter build apk --release --dart-define=API_BASE_URL=http://YOUR_HOST:3000
```

Адрес всё равно можно поменять в Настройках после установки.
