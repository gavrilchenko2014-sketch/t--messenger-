import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:t_messenger/models/models.dart';
import 'package:t_messenger/state/app_state.dart';
import 'package:t_messenger/theme/app_theme.dart';
import 'package:t_messenger/widgets/avatar_view.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key, required this.chat});
  final ChatModel chat;

  @override
  Widget build(BuildContext context) {
    final members = chat.members;
    return Scaffold(
      appBar: AppBar(title: Text(chat.type == 'GROUP' ? 'Группа' : 'Профиль')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Center(child: AvatarView(url: chat.avatarUrl, label: chat.displayTitle, size: 92, online: chat.peer?.isOnline)),
          const SizedBox(height: 16),
          Center(child: Text(chat.displayTitle, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800))),
          if (chat.peer != null)
            Center(child: Text('@${chat.peer!.username}', style: const TextStyle(color: AppColors.muted))),
          const SizedBox(height: 24),
          const Text('Участники', style: TextStyle(color: AppColors.muted)),
          const SizedBox(height: 8),
          ...members.map((raw) {
            final m = Map<String, dynamic>.from(raw as Map);
            final user = m['user'] is Map ? Map<String, dynamic>.from(m['user']) : {};
            final name = user['displayName'] ?? 'участник';
            final uname = user['username'] ?? '';
            return ListTile(
              contentPadding: EdgeInsets.zero,
              leading: AvatarView(url: user['avatarUrl'], label: name, online: user['isOnline'] == true),
              title: Text(name),
              subtitle: Text('@$uname · ${m['role'] ?? 'MEMBER'}', style: const TextStyle(color: AppColors.muted)),
            );
          }),
        ],
      ),
    );
  }
}

class MeProfileScreen extends StatefulWidget {
  const MeProfileScreen({super.key});
  @override
  State<MeProfileScreen> createState() => _MeProfileScreenState();
}

class _MeProfileScreenState extends State<MeProfileScreen> {
  late final c = TextEditingController(text: context.read<AppState>().me?.displayName ?? '');

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final me = context.watch<AppState>().me;
    return Scaffold(
      appBar: AppBar(title: const Text('Мой профиль')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Center(child: AvatarView(url: me?.avatarUrl, label: me?.displayName ?? 'Я', size: 92, online: true)),
          const SizedBox(height: 12),
          Center(child: Text('@${me?.username ?? ''}', style: const TextStyle(color: AppColors.muted))),
          Center(child: Text(me?.id ?? '', style: const TextStyle(color: AppColors.muted, fontSize: 11))),
          const SizedBox(height: 20),
          TextField(controller: c, decoration: const InputDecoration(hintText: 'отображаемое имя')),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () => context.read<AppState>().updateProfile(displayName: c.text.trim()),
            child: const Text('Сохранить'),
          ),
        ],
      ),
    );
  }
}
