import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:t_messenger/screens/auth/register_screen.dart';
import 'package:t_messenger/state/app_state.dart';
import 'package:t_messenger/theme/app_theme.dart';
import 'package:t_messenger/widgets/copper_button.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final login = TextEditingController();
  final password = TextEditingController();

  @override
  void dispose() {
    login.dispose();
    password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(24, 48, 24, 24),
          children: [
            const Text('С возвращением', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            const Text('Войди в T-Messenger — без лишнего шума.', style: TextStyle(color: AppColors.muted)),
            const SizedBox(height: 36),
            TextField(controller: login, decoration: const InputDecoration(hintText: 'username, email или телефон')),
            const SizedBox(height: 12),
            TextField(controller: password, obscureText: true, decoration: const InputDecoration(hintText: 'пароль')),
            if (state.error != null) ...[
              const SizedBox(height: 12),
              Text(state.error!, style: const TextStyle(color: AppColors.danger)),
            ],
            const SizedBox(height: 24),
            CopperButton(
              label: 'Войти',
              loading: state.busy,
              onTap: () async {
                try {
                  await context.read<AppState>().login(login: login.text.trim(), password: password.text);
                } catch (_) {}
              },
            ),
            const SizedBox(height: 16),
            TextButton(
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(builder: (_) => const RegisterScreen()));
              },
              child: const Text('Нет аккаунта? Создать', style: TextStyle(color: AppColors.copper)),
            ),
          ],
        ),
      ),
    );
  }
}
