import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class PushService {
  private readonly log = new Logger(PushService.name);

  constructor(private readonly prisma: PrismaService) {}

  async notifyNewMessage(chatId: string, senderId: string, message: any) {
    const configured = Boolean(process.env.FIREBASE_SERVICE_ACCOUNT);
    const members = await this.prisma.chatMember.findMany({
      where: { chatId, userId: { not: senderId } },
      include: { user: true },
    });
    for (const m of members) {
      if (m.user.isOnline) continue;
      if (!m.user.fcmToken) continue;
      if (!configured) {
        this.log.debug(
          `FCM skipped (no FIREBASE_SERVICE_ACCOUNT). user=${m.user.username} preview=${(message.text || message.type || '').toString().slice(0, 40)}`,
        );
        continue;
      }
      this.log.log(`FCM enqueue to ${m.user.username} token=${m.user.fcmToken.slice(0, 8)}…`);
      // Hook: initialize firebase-admin here when service account is provided.
    }
  }
}
