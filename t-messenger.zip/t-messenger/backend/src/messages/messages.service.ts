import { BadRequestException, Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { ChatsService } from '../chats/chats.service';
import { messageDto } from '../common/serializers';
import { CreateMessageDto } from './dto';
import { PushService } from '../realtime/push.service';
import { EventsHub } from '../realtime/events.hub';

@Injectable()
export class MessagesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly chats: ChatsService,
    private readonly push: PushService,
    private readonly hub: EventsHub,
  ) {}

  async history(chatId: string, userId: string, cursor?: string, limit = 30) {
    await this.chats.assertMember(chatId, userId);
    const take = Math.min(Math.max(Number(limit) || 30, 1), 100);
    const messages = await this.prisma.message.findMany({
      where: {
        chatId,
        ...(cursor ? { createdAt: { lt: new Date(cursor) } } : {}),
      },
      orderBy: { createdAt: 'desc' },
      take: take + 1,
      include: { attachments: true, sender: true },
    });
    const hasMore = messages.length > take;
    const page = hasMore ? messages.slice(0, take) : messages;
    return {
      items: page.map(messageDto).reverse(),
      nextCursor: hasMore ? page[page.length - 1].createdAt.toISOString() : null,
    };
  }

  async create(chatId: string, userId: string, dto: CreateMessageDto, emit = true) {
    await this.chats.assertMember(chatId, userId);
    const type = (dto.type as any) || (dto.attachmentId ? 'IMAGE' : 'TEXT');
    if (type === 'TEXT' && !dto.text?.trim() && !dto.attachmentId) {
      throw new BadRequestException('Пустое сообщение');
    }

    const members = await this.prisma.chatMember.findMany({ where: { chatId } });
    const others = members.filter((m) => m.userId !== userId);

    const message = await this.prisma.message.create({
      data: {
        chatId,
        senderId: userId,
        type,
        text: dto.text?.trim() || null,
        attachments: dto.attachmentId
          ? { connect: { id: dto.attachmentId } }
          : undefined,
        receipts: {
          create: others.map((m) => ({ userId: m.userId })),
        },
      },
      include: { attachments: true, sender: true },
    });

    await this.prisma.chatMember.update({
      where: { chatId_userId: { chatId, userId } },
      data: { lastReadAt: new Date() },
    });

    const payload = messageDto(message);
    if (emit) {
      this.hub.toChat(chatId, 'new_message', payload);
      for (const m of others) {
        this.hub.toUser(m.userId, 'new_message', payload);
      }
    }
    await this.push.notifyNewMessage(chatId, userId, payload);
    return payload;
  }

  async markRead(messageId: string, userId: string) {
    const message = await this.prisma.message.findUnique({
      where: { id: messageId },
    });
    if (!message) return { ok: false };
    await this.chats.assertMember(message.chatId, userId);
    const now = new Date();
    await this.prisma.messageReceipt.upsert({
      where: { messageId_userId: { messageId, userId } },
      update: { readAt: now, deliveredAt: now },
      create: { messageId, userId, readAt: now, deliveredAt: now },
    });
    if (message.senderId !== userId) {
      await this.prisma.message.update({
        where: { id: messageId },
        data: { readAt: now, deliveredAt: message.deliveredAt || now },
      });
    }
    await this.prisma.chatMember.update({
      where: { chatId_userId: { chatId: message.chatId, userId } },
      data: { lastReadAt: now },
    });
    const result = { ok: true, chatId: message.chatId, messageId, readAt: now, readerId: userId };
    this.hub.toChat(message.chatId, 'message_read', result);
    this.hub.toUser(message.senderId, 'message_read', result);
    return result;
  }

  async markDelivered(messageId: string, userId: string) {
    const now = new Date();
    const message = await this.prisma.message.findUnique({ where: { id: messageId } });
    if (!message) return null;
    await this.prisma.messageReceipt.upsert({
      where: { messageId_userId: { messageId, userId } },
      update: { deliveredAt: now },
      create: { messageId, userId, deliveredAt: now },
    });
    if (!message.deliveredAt && message.senderId !== userId) {
      await this.prisma.message.update({
        where: { id: messageId },
        data: { deliveredAt: now },
      });
    }
    const result = { chatId: message.chatId, messageId, deliveredAt: now, userId };
    this.hub.toChat(message.chatId, 'message_delivered', result);
    this.hub.toUser(message.senderId, 'message_delivered', result);
    return result;
  }

  async memberIds(chatId: string) {
    const members = await this.prisma.chatMember.findMany({ where: { chatId } });
    return members.map((m) => m.userId);
  }
}
