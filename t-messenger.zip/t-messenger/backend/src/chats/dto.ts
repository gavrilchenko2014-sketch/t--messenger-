import { ArrayMinSize, IsArray, IsOptional, IsString, MinLength } from 'class-validator';

export class PrivateChatDto {
  @IsString()
  userId: string;
}

export class GroupChatDto {
  @IsString()
  @MinLength(2)
  title: string;

  @IsOptional()
  @IsString()
  avatarUrl?: string;

  @IsArray()
  @ArrayMinSize(1)
  @IsString({ each: true })
  memberIds: string[];
}
