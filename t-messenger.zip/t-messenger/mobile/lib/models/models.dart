class UserModel {
  final String id;
  final String username;
  final String displayName;
  final String? email;
  final String? phone;
  final String? avatarUrl;
  final bool isOnline;
  final DateTime? lastSeen;
  final DateTime? createdAt;

  UserModel({
    required this.id,
    required this.username,
    required this.displayName,
    this.email,
    this.phone,
    this.avatarUrl,
    this.isOnline = false,
    this.lastSeen,
    this.createdAt,
  });

  factory UserModel.fromJson(Map<String, dynamic> j) => UserModel(
        id: j['id'] as String,
        username: j['username'] as String? ?? '',
        displayName: j['displayName'] as String? ?? '',
        email: j['email'] as String?,
        phone: j['phone'] as String?,
        avatarUrl: j['avatarUrl'] as String?,
        isOnline: j['isOnline'] == true,
        lastSeen: j['lastSeen'] != null ? DateTime.tryParse(j['lastSeen']) : null,
        createdAt: j['createdAt'] != null ? DateTime.tryParse(j['createdAt']) : null,
      );
}

class AttachmentModel {
  final String id;
  final String type;
  final String url;
  final String fileName;
  final int fileSize;

  AttachmentModel({
    required this.id,
    required this.type,
    required this.url,
    required this.fileName,
    required this.fileSize,
  });

  factory AttachmentModel.fromJson(Map<String, dynamic> j) => AttachmentModel(
        id: j['id'],
        type: j['type'] ?? 'DOCUMENT',
        url: j['url'] ?? '',
        fileName: j['fileName'] ?? '',
        fileSize: j['fileSize'] ?? 0,
      );
}

class MessageModel {
  final String id;
  final String chatId;
  final String senderId;
  final String type;
  final String? text;
  final DateTime createdAt;
  DateTime? deliveredAt;
  DateTime? readAt;
  final UserModel? sender;
  final List<AttachmentModel> attachments;

  MessageModel({
    required this.id,
    required this.chatId,
    required this.senderId,
    required this.type,
    required this.createdAt,
    this.text,
    this.deliveredAt,
    this.readAt,
    this.sender,
    this.attachments = const [],
  });

  factory MessageModel.fromJson(Map<String, dynamic> j) => MessageModel(
        id: j['id'],
        chatId: j['chatId'],
        senderId: j['senderId'],
        type: j['type'] ?? 'TEXT',
        text: j['text'],
        createdAt: DateTime.tryParse(j['createdAt'] ?? '') ?? DateTime.now(),
        deliveredAt: j['deliveredAt'] != null ? DateTime.tryParse(j['deliveredAt']) : null,
        readAt: j['readAt'] != null ? DateTime.tryParse(j['readAt']) : null,
        sender: j['sender'] is Map<String, dynamic> ? UserModel.fromJson(j['sender']) : null,
        attachments: (j['attachments'] as List? ?? [])
            .map((e) => AttachmentModel.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );
}

class ChatModel {
  final String id;
  final String type;
  final String? title;
  final String? avatarUrl;
  final UserModel? peer;
  final DateTime createdAt;
  final List<dynamic> members;
  MessageModel? lastMessage;
  int unreadCount;

  ChatModel({
    required this.id,
    required this.type,
    required this.createdAt,
    this.title,
    this.avatarUrl,
    this.peer,
    this.members = const [],
    this.lastMessage,
    this.unreadCount = 0,
  });

  factory ChatModel.fromJson(Map<String, dynamic> j) => ChatModel(
        id: j['id'],
        type: j['type'] ?? 'PRIVATE',
        title: j['title'],
        avatarUrl: j['avatarUrl'],
        peer: j['peer'] is Map<String, dynamic> ? UserModel.fromJson(j['peer']) : null,
        createdAt: DateTime.tryParse(j['createdAt'] ?? '') ?? DateTime.now(),
        members: j['members'] as List? ?? const [],
        lastMessage: j['lastMessage'] is Map<String, dynamic>
            ? MessageModel.fromJson({
                ...Map<String, dynamic>.from(j['lastMessage']),
                'chatId': j['id'],
                'senderId': j['lastMessage']['senderId'] ?? '',
              })
            : null,
        unreadCount: j['unreadCount'] ?? 0,
      );

  String get displayTitle {
    if (type == 'GROUP') return title ?? 'Группа';
    return peer?.displayName ?? title ?? 'Чат';
  }
}
