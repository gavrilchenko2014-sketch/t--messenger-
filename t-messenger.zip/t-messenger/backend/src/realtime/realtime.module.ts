import { Module } from '@nestjs/common';
import { ChatGateway } from './chat.gateway';
import { UsersModule } from '../users/users.module';
import { ChatsModule } from '../chats/chats.module';
import { MessagesModule } from '../messages/messages.module';

@Module({
  imports: [UsersModule, ChatsModule, MessagesModule],
  providers: [ChatGateway],
})
export class RealtimeModule {}
