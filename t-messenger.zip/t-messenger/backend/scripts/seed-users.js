/**
 * Creates two demo users if they do not exist.
 * Usage: node scripts/seed-users.js
 */
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function upsertUser({ username, displayName, email, phone, password }) {
  const existing = await prisma.user.findUnique({ where: { username } });
  if (existing) {
    console.log('exists', username, existing.id);
    return existing;
  }
  const user = await prisma.user.create({
    data: {
      username,
      displayName,
      email,
      phone,
      passwordHash: await bcrypt.hash(password, 10),
    },
  });
  console.log('created', username, user.id);
  return user;
}

async function main() {
  await upsertUser({
    username: 'timur',
    displayName: 'Тимур',
    email: 'timur@tmsg.local',
    phone: '+380000000001',
    password: 'Test1234!',
  });
  await upsertUser({
    username: 'eva',
    displayName: 'Ева',
    email: 'eva@tmsg.local',
    phone: '+380000000002',
    password: 'Test1234!',
  });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
