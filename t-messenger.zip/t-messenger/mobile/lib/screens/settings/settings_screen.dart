import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:t_messenger/screens/profile/profile_screen.dart';
import 'package:t_messenger/state/app_state.dart';
import 'package:t_messenger/theme/app_theme.dart';
import 'package:t_messenger/widgets/avatar_view.dart';
import 'package:t_messenger/widgets/copper_button.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final url = TextEditingController(text: context.read<AppState>().serverUrl);

  @override
  void dispose() {
    url.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final me = state.me;
    return Scaffold(
      appBar: AppBar(title: const Text('Настройки')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: AvatarView(url: me?.avatarUrl, label: me?.displayName ?? 'Я', online: true),
            title: Text(me?.displayName ?? ''),
            subtitle: Text('@${me?.username ?? ''}', style: const TextStyle(color: AppColors.muted)),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MeProfileScreen())),
          ),
          const SizedBox(height: 24),
          const Text('Сервер', style: TextStyle(color: AppColors.muted)),
          const SizedBox(height: 8),
          TextField(controller: url, decoration: const InputDecoration(hintText: 'http://192.168.0.12:3000')),
          const SizedBox(height: 10),
          CopperButton(
            label: 'Сохранить адрес',
            onTap: () async {
              await context.read<AppState>().updateServerUrl(url.text.trim());
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Адрес сервера обновлён')));
              }
            },
          ),
          const SizedBox(height: 28),
          const Text(
            'Для двух телефонов через интернет укажите публичный URL backend (VPS или ngrok). На одной Wi‑Fi сети — IP компьютера, например http://192.168.0.15:3000',
            style: TextStyle(color: AppColors.muted, height: 1.4),
          ),
          const SizedBox(height: 28),
          OutlinedButton(
            onPressed: () => context.read<AppState>().logout(),
            style: OutlinedButton.styleFrom(foregroundColor: AppColors.danger, side: const BorderSide(color: AppColors.danger)),
            child: const Text('Выйти из аккаунта'),
          ),
        ],
      ),
    );
  }
}
