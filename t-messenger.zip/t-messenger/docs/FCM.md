# Firebase Cloud Messaging

Архитектура уже есть:

- поле `User.fcmToken`
- `POST /users/me/push-token` `{ "token": "..." }`
- `PushService.notifyNewMessage` вызывается на каждое новое сообщение
- если `FIREBASE_SERVICE_ACCOUNT` пуст, push не отправляется, чат работает

## Клиент

1. Firebase Console → Add Android app.
2. Скачать `google-services.json` → `mobile/android/app/google-services.json`.
3. Подключить `firebase_core` + `firebase_messaging` в `pubspec.yaml`.
4. После логина вызвать `POST /users/me/push-token`.

## Сервер

Положите JSON сервис-аккаунта на машину backend и укажите путь:

```
FIREBASE_SERVICE_ACCOUNT=/run/secrets/firebase.json
```

Дальше в `backend/src/realtime/push.service.ts` инициализируется `firebase-admin`.
Сейчас там безопасная заглушка, чтобы MVP собирался без Firebase.
