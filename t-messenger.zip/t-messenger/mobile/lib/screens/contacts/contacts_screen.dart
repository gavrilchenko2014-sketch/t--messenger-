import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:t_messenger/screens/chat/chat_screen.dart';
import 'package:t_messenger/state/app_state.dart';
import 'package:t_messenger/theme/app_theme.dart';
import 'package:t_messenger/widgets/avatar_view.dart';

class ContactsScreen extends StatefulWidget {
  const ContactsScreen({super.key});
  @override
  State<ContactsScreen> createState() => _ContactsScreenState();
}

class _ContactsScreenState extends State<ContactsScreen> {
  final q = TextEditingController();

  @override
  void dispose() {
    q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('Контакты')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: q,
              onChanged: (v) {
                if (v.trim().length >= 1) state.searchUsers(v.trim());
              },
              decoration: const InputDecoration(
                hintText: 'поиск по username или имени',
                prefixIcon: Icon(Icons.search, color: AppColors.muted),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: state.searchResults.length,
              itemBuilder: (_, i) {
                final u = state.searchResults[i];
                return ListTile(
                  leading: AvatarView(url: u.avatarUrl, label: u.displayName, online: u.isOnline),
                  title: Text(u.displayName),
                  subtitle: Text('@${u.username}', style: const TextStyle(color: AppColors.muted)),
                  trailing: const Text('Написать', style: TextStyle(color: AppColors.copper)),
                  onTap: () async {
                    final chat = await context.read<AppState>().openPrivate(u.id);
                    if (!context.mounted) return;
                    Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChatScreen(chat: chat)));
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
