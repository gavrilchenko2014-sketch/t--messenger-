import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:t_messenger/theme/app_theme.dart';

class AvatarView extends StatelessWidget {
  const AvatarView({super.key, this.url, required this.label, this.size = 46, this.online});
  final String? url;
  final String label;
  final double size;
  final bool? online;

  @override
  Widget build(BuildContext context) {
    final letter = label.isNotEmpty ? label.characters.first.toUpperCase() : '?';
    return Stack(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(size / 3),
          child: url != null && url!.isNotEmpty
              ? CachedNetworkImage(imageUrl: url!, width: size, height: size, fit: BoxFit.cover)
              : Container(
                  width: size,
                  height: size,
                  color: AppColors.surface2,
                  alignment: Alignment.center,
                  child: Text(letter, style: TextStyle(color: AppColors.copper, fontWeight: FontWeight.w800, fontSize: size / 2.4)),
                ),
        ),
        if (online != null)
          Positioned(
            right: 0,
            bottom: 0,
            child: Container(
              width: 12,
              height: 12,
              decoration: BoxDecoration(
                color: online! ? AppColors.mint : AppColors.muted,
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.bg, width: 2),
              ),
            ),
          ),
      ],
    );
  }
}
