import { BadRequestException, Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { existsSync, mkdirSync } from 'fs';
import { join } from 'path';

const ALLOWED = new Set([
  'image/jpeg',
  'image/png',
  'image/webp',
  'image/gif',
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/zip',
  'text/plain',
  'video/mp4',
  'audio/mpeg',
  'audio/mp4',
  'audio/ogg',
  'audio/webm',
]);

@Injectable()
export class UploadsService {
  constructor(private readonly prisma: PrismaService) {
    const dir = join(process.cwd(), 'uploads');
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
  }

  async save(file: Express.Multer.File) {
    if (!file) throw new BadRequestException('Файл не передан');
    if (!ALLOWED.has(file.mimetype)) {
      throw new BadRequestException('Тип файла не поддерживается');
    }
    const max = Number(process.env.MAX_FILE_SIZE || 10 * 1024 * 1024);
    if (file.size > max) throw new BadRequestException('Файл слишком большой');

    const type = file.mimetype.startsWith('image/')
      ? 'IMAGE'
      : file.mimetype.startsWith('video/')
        ? 'VIDEO'
        : file.mimetype.startsWith('audio/')
          ? 'VOICE'
          : 'DOCUMENT';

    const publicBase = (process.env.API_PUBLIC_URL || 'http://localhost:3000').replace(/\/$/, '');
    const url = `${publicBase}/uploads/${file.filename}`;

    return this.prisma.attachment.create({
      data: {
        type,
        url,
        fileName: file.originalname || file.filename,
        fileSize: file.size,
        mimeType: file.mimetype,
      },
    });
  }
}
