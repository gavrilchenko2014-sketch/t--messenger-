import { Controller, Post, UploadedFile, UseGuards, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { extname, join } from 'path';
import { v4 as uuid } from 'uuid';
import { JwtAuthGuard } from '../common/jwt-auth.guard';
import { UploadsService } from './uploads.service';

@Controller('uploads')
@UseGuards(JwtAuthGuard)
export class UploadsController {
  constructor(private readonly uploads: UploadsService) {}

  @Post()
  @UseInterceptors(
    FileInterceptor('file', {
      storage: diskStorage({
        destination: (_req, _file, cb) => cb(null, join(process.cwd(), 'uploads')),
        filename: (_req, file, cb) => {
          const ext = extname(file.originalname || '').slice(0, 8) || '';
          cb(null, `${uuid()}${ext}`);
        },
      }),
      limits: { fileSize: Number(process.env.MAX_FILE_SIZE || 10 * 1024 * 1024) },
    }),
  )
  upload(@UploadedFile() file: Express.Multer.File) {
    return this.uploads.save(file);
  }
}
