import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:t_messenger/config.dart';

class ApiClient {
  ApiClient();

  final Dio dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 12),
    receiveTimeout: const Duration(seconds: 20),
  ));

  String baseUrl = AppConfig.defaultBaseUrl;
  String? token;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    baseUrl = prefs.getString('apiBaseUrl') ?? AppConfig.defaultBaseUrl;
    token = prefs.getString('accessToken');
    _apply();
  }

  Future<void> setBaseUrl(String url) async {
    baseUrl = url.replaceAll(RegExp(r'/$'), '');
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('apiBaseUrl', baseUrl);
    _apply();
  }

  Future<void> setToken(String? value) async {
    token = value;
    final prefs = await SharedPreferences.getInstance();
    if (value == null) {
      await prefs.remove('accessToken');
    } else {
      await prefs.setString('accessToken', value);
    }
    _apply();
  }

  void _apply() {
    dio.options.baseUrl = baseUrl;
    dio.options.headers = {
      'Content-Type': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  Future<Response<T>> get<T>(String path, {Map<String, dynamic>? query}) {
    return dio.get<T>(path, queryParameters: query);
  }

  Future<Response<T>> post<T>(String path, {dynamic data}) {
    return dio.post<T>(path, data: data);
  }

  Future<Response<T>> patch<T>(String path, {dynamic data}) {
    return dio.patch<T>(path, data: data);
  }
}
