import { IsIn, IsOptional, IsString, MaxLength } from 'class-validator';

export class CreateMessageDto {
  @IsOptional()
  @IsIn(['TEXT', 'IMAGE', 'DOCUMENT', 'VIDEO', 'VOICE', 'SYSTEM'])
  type?: string;

  @IsOptional()
  @IsString()
  @MaxLength(4000)
  text?: string;

  @IsOptional()
  @IsString()
  attachmentId?: string;
}
