# Flutter-клиент T-Messenger

```bash
cd mobile
flutter create . --project-name t_messenger --org com.tmessenger
flutter pub get
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:3000
```

На настоящем телефоне в **Настройки → Сервер** укажите IP компьютера или публичный URL.

Подробности: `../docs/ANDROID.md` и `../docs/TWO_PHONES.md`.
