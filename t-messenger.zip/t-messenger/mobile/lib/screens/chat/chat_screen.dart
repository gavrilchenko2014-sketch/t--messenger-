import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:t_messenger/models/models.dart';
import 'package:t_messenger/screens/profile/profile_screen.dart';
import 'package:t_messenger/state/app_state.dart';
import 'package:t_messenger/theme/app_theme.dart';
import 'package:t_messenger/widgets/avatar_view.dart';

const _emoji = ['😀','😁','😂','😊','😍','😘','😎','🤔','😴','😭','😡','👍','👎','🔥','✨','❤️','🇺🇦','🎉','☕','🌙'];

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.chat});
  final ChatModel chat;
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final input = TextEditingController();
  final scroll = ScrollController();
  bool emojiOpen = false;
  late final AppState app;
  String? lastId;

  @override
  void initState() {
    super.initState();
    app = context.read<AppState>();
    app.openChat(widget.chat.id);
    app.loadMessages(widget.chat.id, reset: true).then((_) {
      app.markVisibleRead(widget.chat.id);
      _jumpEnd();
    });
    scroll.addListener(() {
      if (scroll.position.pixels <= 40) {
        app.loadMessages(widget.chat.id);
      }
    });
  }

  @override
  void dispose() {
    app.closeChat(widget.chat.id);
    input.dispose();
    scroll.dispose();
    super.dispose();
  }

  void _jumpEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!scroll.hasClients) return;
      scroll.jumpTo(scroll.position.maxScrollExtent);
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final msgs = state.messages[widget.chat.id] ?? [];
    final meId = state.me?.id;
    final newest = msgs.isNotEmpty ? msgs.last.id : null;
    if (newest != null && newest != lastId) {
      lastId = newest;
      WidgetsBinding.instance.addPostFrameCallback((_) => _jumpEnd());
    }

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: InkWell(
          onTap: () => Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => ProfileScreen(chat: widget.chat),
          )),
          child: Row(
            children: [
              AvatarView(url: widget.chat.avatarUrl, label: widget.chat.displayTitle, size: 36, online: widget.chat.peer?.isOnline),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.chat.displayTitle, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                    Text(
                      state.typingUserId != null
                          ? 'печатает…'
                          : (widget.chat.peer?.isOnline == true ? 'в сети' : 'был(а) недавно'),
                      style: const TextStyle(fontSize: 12, color: AppColors.muted),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        actions: [
          IconButton(
            onPressed: () => _soon('Голосовой звонок'),
            icon: const Icon(Icons.call_outlined),
          ),
          IconButton(
            onPressed: () => _soon('Видеозвонок'),
            icon: const Icon(Icons.videocam_outlined),
          ),
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'profile') {
                Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProfileScreen(chat: widget.chat)));
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'profile', child: Text('Профиль / участники')),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: scroll,
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
              itemCount: msgs.length,
              itemBuilder: (_, i) {
                final m = msgs[i];
                final mine = m.senderId == meId;
                return Align(
                  alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.fromLTRB(12, 8, 12, 6),
                    decoration: BoxDecoration(
                      color: mine ? AppColors.bubbleMe : AppColors.bubbleOther,
                      borderRadius: BorderRadius.only(
                        topLeft: const Radius.circular(16),
                        topRight: const Radius.circular(16),
                        bottomLeft: Radius.circular(mine ? 16 : 4),
                        bottomRight: Radius.circular(mine ? 4 : 16),
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        if (!mine && widget.chat.type == 'GROUP')
                          Padding(
                            padding: const EdgeInsets.only(bottom: 4),
                            child: Text(m.sender?.displayName ?? '', style: const TextStyle(color: AppColors.copper, fontSize: 12)),
                          ),
                        if (m.attachments.isNotEmpty)
                          ...m.attachments.map((a) => Padding(
                                padding: const EdgeInsets.only(bottom: 6),
                                child: a.type == 'IMAGE'
                                    ? ClipRRect(
                                        borderRadius: BorderRadius.circular(10),
                                        child: Image.network(a.url, width: 220, fit: BoxFit.cover),
                                      )
                                    : Row(mainAxisSize: MainAxisSize.min, children: [
                                        const Icon(Icons.insert_drive_file_outlined, size: 18, color: AppColors.copper),
                                        const SizedBox(width: 6),
                                        Flexible(child: Text(a.fileName, overflow: TextOverflow.ellipsis)),
                                      ]),
                              )),
                        if ((m.text ?? '').isNotEmpty)
                          Align(alignment: Alignment.centerLeft, child: Text(m.text!, style: const TextStyle(height: 1.3))),
                        const SizedBox(height: 4),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(DateFormat.Hm().format(m.createdAt.toLocal()), style: const TextStyle(fontSize: 10, color: AppColors.muted)),
                            if (mine) ...[
                              const SizedBox(width: 4),
                              Icon(
                                m.readAt != null
                                    ? Icons.done_all
                                    : m.deliveredAt != null
                                        ? Icons.done_all
                                        : Icons.check,
                                size: 14,
                                color: m.readAt != null ? AppColors.mint : AppColors.muted,
                              ),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          if (emojiOpen)
            SizedBox(
              height: 160,
              child: GridView.count(
                crossAxisCount: 8,
                children: _emoji
                    .map((e) => InkWell(
                          onTap: () => setState(() => input.text += e),
                          child: Center(child: Text(e, style: const TextStyle(fontSize: 22))),
                        ))
                    .toList(),
              ),
            ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(8, 6, 8, 8),
              child: Row(
                children: [
                  IconButton(
                    onPressed: _attach,
                    icon: const Icon(Icons.attach_file, color: AppColors.muted),
                  ),
                  IconButton(
                    onPressed: () => setState(() => emojiOpen = !emojiOpen),
                    icon: const Icon(Icons.emoji_emotions_outlined, color: AppColors.muted),
                  ),
                  Expanded(
                    child: TextField(
                      controller: input,
                      minLines: 1,
                      maxLines: 4,
                      onChanged: (v) {
                        context.read<AppState>().socket.typing(widget.chat.id, v.isNotEmpty);
                      },
                      decoration: const InputDecoration(hintText: 'Сообщение'),
                    ),
                  ),
                  const SizedBox(width: 6),
                  CircleAvatar(
                    backgroundColor: AppColors.copper,
                    child: IconButton(
                      onPressed: () async {
                        final text = input.text;
                        input.clear();
                        await context.read<AppState>().sendText(widget.chat.id, text);
                        context.read<AppState>().socket.typing(widget.chat.id, false);
                      },
                      icon: const Icon(Icons.north, color: AppColors.bg),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _attach() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: AppColors.surface,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.photo_outlined), title: const Text('Фото'), onTap: () => Navigator.pop(context, 'photo')),
          ListTile(leading: const Icon(Icons.insert_drive_file_outlined), title: const Text('Документ'), onTap: () => Navigator.pop(context, 'doc')),
        ]),
      ),
    );
    final state = context.read<AppState>();
    if (choice == 'photo') {
      final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 82);
      if (x == null) return;
      final bytes = await x.readAsBytes();
      await state.sendAttachment(
        widget.chat.id,
        MultipartFile.fromBytes(bytes, filename: x.name),
        'IMAGE',
      );
    } else if (choice == 'doc') {
      final r = await FilePicker.platform.pickFiles(withData: true);
      if (r == null || r.files.single.bytes == null) return;
      final f = r.files.single;
      await state.sendAttachment(
        widget.chat.id,
        MultipartFile.fromBytes(f.bytes!, filename: f.name),
        'DOCUMENT',
      );
    }
  }

  void _soon(String title) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: Text(title),
        content: const Text('Слой WebRTC уже заложен на сервере (call_offer / call_answer / call_ice). В этой версии звонок ещё не поднимает медиапоток.'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Понятно'))],
      ),
    );
  }
}
