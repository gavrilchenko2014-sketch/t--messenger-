import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:t_messenger/screens/chat/chat_screen.dart';
import 'package:t_messenger/state/app_state.dart';
import 'package:t_messenger/theme/app_theme.dart';
import 'package:t_messenger/widgets/copper_button.dart';

class CreateGroupScreen extends StatefulWidget {
  const CreateGroupScreen({super.key});
  @override
  State<CreateGroupScreen> createState() => _CreateGroupScreenState();
}

class _CreateGroupScreenState extends State<CreateGroupScreen> {
  final title = TextEditingController();
  final q = TextEditingController();
  final selected = <String, String>{};

  @override
  void dispose() {
    title.dispose();
    q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('Новая группа')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: title, decoration: const InputDecoration(hintText: 'название группы')),
            const SizedBox(height: 12),
            TextField(
              controller: q,
              onChanged: (v) => state.searchUsers(v.trim()),
              decoration: const InputDecoration(hintText: 'добавить участников по username'),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: selected.entries
                  .map((e) => Chip(
                        label: Text(e.value),
                        onDeleted: () => setState(() => selected.remove(e.key)),
                      ))
                  .toList(),
            ),
            Expanded(
              child: ListView(
                children: state.searchResults
                    .map((u) => ListTile(
                          title: Text(u.displayName),
                          subtitle: Text('@${u.username}'),
                          trailing: Icon(selected.containsKey(u.id) ? Icons.check_circle : Icons.circle_outlined, color: AppColors.copper),
                          onTap: () => setState(() {
                            if (selected.containsKey(u.id)) {
                              selected.remove(u.id);
                            } else {
                              selected[u.id] = u.displayName;
                            }
                          }),
                        ))
                    .toList(),
              ),
            ),
            CopperButton(
              label: 'Создать',
              onTap: () async {
                if (title.text.trim().length < 2 || selected.isEmpty) return;
                final chat = await context.read<AppState>().createGroup(title.text.trim(), selected.keys.toList());
                if (!context.mounted) return;
                Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => ChatScreen(chat: chat)));
              },
            ),
          ],
        ),
      ),
    );
  }
}
