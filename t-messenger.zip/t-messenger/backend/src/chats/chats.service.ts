import {
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { publicUser } from '../common/serializers';
import { GroupChatDto } from './dto';

@Injectable()
export class ChatsService {
  constructor(private readonly prisma: PrismaService) {}

  async assertMember(chatId: string, userId: string) {
    const member = await this.prisma.chatMember.findUnique({
      where: { chatId_userId: { chatId, userId } },
    });
    if (!member) throw new ForbiddenException('Нет доступа к чату');
    return member;
  }

  async list(userId: string) {
    const memberships = await this.prisma.chatMember.findMany({
      where: { userId },
      include: {
        chat: {
          include: {
            members: { include: { user: true } },
            messages: {
              orderBy: { createdAt: 'desc' },
              take: 1,
              include: { attachments: true, sender: true },
            },
          },
        },
      },
    });

    const items = await Promise.all(
      memberships.map(async (m) => {
        const last = m.chat.messages[0] || null;
        const unread = await this.prisma.message.count({
          where: {
            chatId: m.chatId,
            senderId: { not: userId },
            createdAt: { gt: m.lastReadAt || new Date(0) },
          },
        });
        return this.serializeChat(m.chat, userId, last, unread);
      }),
    );

    items.sort((a, b) => {
      const ta = a.lastMessage?.createdAt || a.createdAt;
      const tb = b.lastMessage?.createdAt || b.createdAt;
      return new Date(tb).getTime() - new Date(ta).getTime();
    });
    return items;
  }

  async getOne(chatId: string, userId: string) {
    await this.assertMember(chatId, userId);
    const chat = await this.prisma.chat.findUnique({
      where: { id: chatId },
      include: { members: { include: { user: true } } },
    });
    if (!chat) throw new NotFoundException('Чат не найден');
    return this.serializeChat(chat, userId, null, 0);
  }

  async createPrivate(meId: string, otherUserId: string) {
    if (meId === otherUserId) {
      throw new ForbiddenException('Нельзя создать чат с собой');
    }
    const other = await this.prisma.user.findUnique({ where: { id: otherUserId } });
    if (!other) throw new NotFoundException('Пользователь не найден');

    const existing = await this.prisma.chat.findFirst({
      where: {
        type: 'PRIVATE',
        AND: [
          { members: { some: { userId: meId } } },
          { members: { some: { userId: otherUserId } } },
        ],
      },
      include: { members: { include: { user: true } } },
    });
    if (existing) return this.serializeChat(existing, meId, null, 0);

    const chat = await this.prisma.chat.create({
      data: {
        type: 'PRIVATE',
        members: {
          create: [
            { userId: meId, role: 'MEMBER' },
            { userId: otherUserId, role: 'MEMBER' },
          ],
        },
      },
      include: { members: { include: { user: true } } },
    });
    return this.serializeChat(chat, meId, null, 0);
  }

  async createGroup(meId: string, dto: GroupChatDto) {
    const uniqueIds = Array.from(new Set([meId, ...dto.memberIds]));
    const chat = await this.prisma.chat.create({
      data: {
        type: 'GROUP',
        title: dto.title.trim(),
        avatarUrl: dto.avatarUrl,
        members: {
          create: uniqueIds.map((id) => ({
            userId: id,
            role: id === meId ? 'OWNER' : 'MEMBER',
          })),
        },
      },
      include: { members: { include: { user: true } } },
    });
    return this.serializeChat(chat, meId, null, 0);
  }

  serializeChat(chat: any, meId: string, lastMessage: any, unreadCount: number) {
    const members = (chat.members || []).map((m: any) => ({
      userId: m.userId,
      role: m.role,
      joinedAt: m.joinedAt,
      user: publicUser(m.user),
    }));
    const other =
      chat.type === 'PRIVATE'
        ? members.find((m: any) => m.userId !== meId)?.user || null
        : null;
    return {
      id: chat.id,
      type: chat.type,
      title: chat.type === 'GROUP' ? chat.title : other?.displayName || chat.title,
      avatarUrl: chat.type === 'GROUP' ? chat.avatarUrl : other?.avatarUrl,
      peer: other,
      createdAt: chat.createdAt,
      members,
      lastMessage: lastMessage
        ? {
            id: lastMessage.id,
            text: lastMessage.text,
            type: lastMessage.type,
            createdAt: lastMessage.createdAt,
            senderId: lastMessage.senderId,
          }
        : null,
      unreadCount,
    };
  }
}
