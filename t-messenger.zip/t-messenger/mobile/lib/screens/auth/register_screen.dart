import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:t_messenger/state/app_state.dart';
import 'package:t_messenger/theme/app_theme.dart';
import 'package:t_messenger/widgets/copper_button.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final username = TextEditingController();
  final displayName = TextEditingController();
  final email = TextEditingController();
  final phone = TextEditingController();
  final password = TextEditingController();

  @override
  void dispose() {
    username.dispose();
    displayName.dispose();
    email.dispose();
    phone.dispose();
    password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('Регистрация')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const Text('Новый контур связи', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
          const SizedBox(height: 20),
          TextField(controller: username, decoration: const InputDecoration(hintText: 'username')),
          const SizedBox(height: 12),
          TextField(controller: displayName, decoration: const InputDecoration(hintText: 'отображаемое имя')),
          const SizedBox(height: 12),
          TextField(controller: email, decoration: const InputDecoration(hintText: 'email (или оставь пустым)')),
          const SizedBox(height: 12),
          TextField(controller: phone, decoration: const InputDecoration(hintText: 'телефон (или оставь пустым)')),
          const SizedBox(height: 12),
          TextField(controller: password, obscureText: true, decoration: const InputDecoration(hintText: 'пароль от 6 символов')),
          if (state.error != null) ...[
            const SizedBox(height: 12),
            Text(state.error!, style: const TextStyle(color: AppColors.danger)),
          ],
          const SizedBox(height: 24),
          CopperButton(
            label: 'Создать аккаунт',
            loading: state.busy,
            onTap: () async {
              try {
                await context.read<AppState>().register(
                      username: username.text.trim(),
                      displayName: displayName.text.trim(),
                      password: password.text,
                      email: email.text.trim(),
                      phone: phone.text.trim(),
                    );
                if (context.mounted) Navigator.of(context).pop();
              } catch (_) {}
            },
          ),
        ],
      ),
    );
  }
}
