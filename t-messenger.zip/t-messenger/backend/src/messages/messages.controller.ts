import { Body, Controller, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import { MessagesService } from './messages.service';
import { JwtAuthGuard } from '../common/jwt-auth.guard';
import { CurrentUser } from '../common/current-user.decorator';
import { CreateMessageDto } from './dto';

@Controller()
@UseGuards(JwtAuthGuard)
export class MessagesController {
  constructor(private readonly messages: MessagesService) {}

  @Get('chats/:id/messages')
  history(
    @CurrentUser() user: any,
    @Param('id') id: string,
    @Query('cursor') cursor?: string,
    @Query('limit') limit?: string,
  ) {
    return this.messages.history(id, user.id, cursor, limit ? Number(limit) : 30);
  }

  @Post('chats/:id/messages')
  create(
    @CurrentUser() user: any,
    @Param('id') id: string,
    @Body() dto: CreateMessageDto,
  ) {
    return this.messages.create(id, user.id, dto);
  }

  @Post('messages/:id/read')
  read(@CurrentUser() user: any, @Param('id') id: string) {
    return this.messages.markRead(id, user.id);
  }
}
