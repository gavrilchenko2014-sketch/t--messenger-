import 'package:flutter/material.dart';
import 'package:t_messenger/theme/app_theme.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _Logo(),
            SizedBox(height: 18),
            Text('T-Messenger', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w700, color: AppColors.copper)),
            SizedBox(height: 8),
            Text('тихий сигнал между своими', style: TextStyle(color: AppColors.muted)),
          ],
        ),
      ),
    );
  }
}

class _Logo extends StatelessWidget {
  const _Logo();
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 84,
      height: 84,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: const LinearGradient(
          colors: [AppColors.copperDeep, AppColors.copper],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: const Center(
        child: Text('T', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w800, color: AppColors.bg)),
      ),
    );
  }
}
