import { Global, Module } from '@nestjs/common';
import { EventsHub } from './events.hub';
import { PushService } from './push.service';

@Global()
@Module({
  providers: [EventsHub, PushService],
  exports: [EventsHub, PushService],
})
export class EventsModule {}
