import { Injectable } from '@nestjs/common';
import { Server } from 'socket.io';

@Injectable()
export class EventsHub {
  server: Server | null = null;

  setServer(server: Server) {
    this.server = server;
  }

  toChat(chatId: string, event: string, payload: any) {
    this.server?.to(`chat:${chatId}`).emit(event, payload);
  }

  toUser(userId: string, event: string, payload: any) {
    this.server?.to(`user:${userId}`).emit(event, payload);
  }

  broadcast(event: string, payload: any) {
    this.server?.emit(event, payload);
  }
}
