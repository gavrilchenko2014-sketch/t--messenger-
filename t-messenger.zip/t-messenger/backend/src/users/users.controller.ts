import { Body, Controller, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { UsersService } from './users.service';
import { JwtAuthGuard } from '../common/jwt-auth.guard';
import { CurrentUser } from '../common/current-user.decorator';
import { PushTokenDto, UpdateMeDto } from './dto';

@Controller('users')
@UseGuards(JwtAuthGuard)
export class UsersController {
  constructor(private readonly users: UsersService) {}

  @Get('me')
  me(@CurrentUser() user: any) {
    return this.users.me(user.id);
  }

  @Patch('me')
  updateMe(@CurrentUser() user: any, @Body() dto: UpdateMeDto) {
    return this.users.updateMe(user.id, dto);
  }

  @Post('me/push-token')
  pushToken(@CurrentUser() user: any, @Body() dto: PushTokenDto) {
    return this.users.setPushToken(user.id, dto.token);
  }

  @Get('search')
  search(@CurrentUser() user: any, @Query('q') q: string) {
    return this.users.search(q, user.id);
  }

  @Get(':id')
  getById(@Param('id') id: string) {
    return this.users.getById(id);
  }
}
