import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:t_messenger/screens/chat/chat_screen.dart';
import 'package:t_messenger/screens/groups/create_group_screen.dart';
import 'package:t_messenger/state/app_state.dart';
import 'package:t_messenger/theme/app_theme.dart';
import 'package:t_messenger/widgets/avatar_view.dart';

class ChatsScreen extends StatefulWidget {
  const ChatsScreen({super.key});
  @override
  State<ChatsScreen> createState() => _ChatsScreenState();
}

class _ChatsScreenState extends State<ChatsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AppState>().refreshChats();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Чаты'),
        actions: [
          IconButton(
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CreateGroupScreen())),
            icon: const Icon(Icons.group_add_outlined),
          ),
        ],
      ),
      body: RefreshIndicator(
        color: AppColors.copper,
        onRefresh: state.refreshChats,
        child: state.chats.isEmpty
            ? ListView(children: const [
                SizedBox(height: 120),
                Center(child: Text('Пока тихо.\nНайди человека во вкладке Контакты.', textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted))),
              ])
            : ListView.separated(
                itemCount: state.chats.length,
                separatorBuilder: (_, __) => const Divider(height: 1, color: Color(0x14FFFFFF)),
                itemBuilder: (_, i) {
                  final c = state.chats[i];
                  final time = c.lastMessage?.createdAt;
                  return ListTile(
                    onTap: () {
                      Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChatScreen(chat: c)));
                    },
                    leading: AvatarView(
                      url: c.avatarUrl,
                      label: c.displayTitle,
                      online: c.peer?.isOnline,
                    ),
                    title: Text(c.displayTitle, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text(
                      c.lastMessage?.text ??
                          (c.lastMessage?.type == 'IMAGE'
                              ? 'Фото'
                              : c.lastMessage?.type == 'DOCUMENT'
                                  ? 'Документ'
                                  : 'Нет сообщений'),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: AppColors.muted),
                    ),
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        if (time != null)
                          Text(DateFormat.Hm().format(time.toLocal()), style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                        if (c.unreadCount > 0) ...[
                          const SizedBox(height: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                            decoration: BoxDecoration(color: AppColors.copper, borderRadius: BorderRadius.circular(10)),
                            child: Text('${c.unreadCount}', style: const TextStyle(color: AppColors.bg, fontSize: 11, fontWeight: FontWeight.w800)),
                          ),
                        ],
                      ],
                    ),
                  );
                },
              ),
      ),
    );
  }
}
