import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:t_messenger/models/models.dart';
import 'package:t_messenger/services/api_client.dart';
import 'package:t_messenger/services/socket_service.dart';

class AppState extends ChangeNotifier {
  final api = ApiClient();
  late final SocketService socket = SocketService(api);

  bool booting = true;
  bool busy = false;
  String? error;
  UserModel? me;
  List<ChatModel> chats = [];
  List<UserModel> searchResults = [];
  final Map<String, List<MessageModel>> messages = {};
  final Map<String, String?> nextCursor = {};
  String? activeChatId;
  String? typingUserId;
  String serverUrl = '';

  bool get isAuthed => api.token != null && me != null;

  Future<void> bootstrap() async {
    await api.load();
    serverUrl = api.baseUrl;
    if (api.token != null) {
      try {
        await _loadMe();
        await refreshChats();
        _bindSocket();
      } catch (_) {
        await logout();
      }
    }
    booting = false;
    notifyListeners();
  }

  Future<void> updateServerUrl(String url) async {
    await api.setBaseUrl(url);
    serverUrl = api.baseUrl;
    notifyListeners();
    if (isAuthed) {
      _bindSocket();
      await refreshChats();
    }
  }

  Future<void> register({
    required String username,
    required String displayName,
    required String password,
    String? email,
    String? phone,
  }) async {
    await _authPost('/auth/register', {
      'username': username,
      'displayName': displayName,
      'password': password,
      if (email != null && email.isNotEmpty) 'email': email,
      if (phone != null && phone.isNotEmpty) 'phone': phone,
    });
  }

  Future<void> login({required String login, required String password}) async {
    await _authPost('/auth/login', {'login': login, 'password': password});
  }

  Future<void> _authPost(String path, Map data) async {
    busy = true;
    error = null;
    notifyListeners();
    try {
      final res = await api.post(path, data: data);
      final body = Map<String, dynamic>.from(res.data);
      await api.setToken(body['accessToken']);
      me = UserModel.fromJson(Map<String, dynamic>.from(body['user']));
      await refreshChats();
      _bindSocket();
    } on DioException catch (e) {
      error = _err(e);
      rethrow;
    } finally {
      busy = false;
      notifyListeners();
    }
  }

  Future<void> logout() async {
    socket.disconnect();
    await api.setToken(null);
    me = null;
    chats = [];
    messages.clear();
    notifyListeners();
  }

  Future<void> _loadMe() async {
    final res = await api.get('/users/me');
    me = UserModel.fromJson(Map<String, dynamic>.from(res.data));
  }

  Future<void> updateProfile({String? displayName, String? avatarUrl}) async {
    final res = await api.patch('/users/me', data: {
      if (displayName != null) 'displayName': displayName,
      if (avatarUrl != null) 'avatarUrl': avatarUrl,
    });
    me = UserModel.fromJson(Map<String, dynamic>.from(res.data));
    notifyListeners();
  }

  Future<void> refreshChats() async {
    if (api.token == null) return;
    final res = await api.get('/chats');
    chats = (res.data as List)
        .map((e) => ChatModel.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    notifyListeners();
  }

  Future<void> searchUsers(String q) async {
    final res = await api.get('/users/search', query: {'q': q});
    searchResults = (res.data as List)
        .map((e) => UserModel.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    notifyListeners();
  }

  Future<ChatModel> openPrivate(String userId) async {
    final res = await api.post('/chats/private', data: {'userId': userId});
    final chat = ChatModel.fromJson(Map<String, dynamic>.from(res.data));
    _upsertChat(chat);
    return chat;
  }

  Future<ChatModel> createGroup(String title, List<String> memberIds) async {
    final res = await api.post('/chats/group', data: {
      'title': title,
      'memberIds': memberIds,
    });
    final chat = ChatModel.fromJson(Map<String, dynamic>.from(res.data));
    _upsertChat(chat);
    return chat;
  }

  Future<void> loadMessages(String chatId, {bool reset = false}) async {
    if (reset) {
      messages[chatId] = [];
      nextCursor[chatId] = null;
    }
    final cursor = reset ? null : nextCursor[chatId];
    final res = await api.get('/chats/$chatId/messages', query: {
      if (cursor != null) 'cursor': cursor,
      'limit': 30,
    });
    final body = Map<String, dynamic>.from(res.data);
    final items = (body['items'] as List)
        .map((e) => MessageModel.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    final existing = messages[chatId] ?? [];
    if (reset) {
      messages[chatId] = items;
    } else {
      messages[chatId] = [...items, ...existing];
    }
    nextCursor[chatId] = body['nextCursor'] as String?;
    notifyListeners();
  }

  Future<void> sendText(String chatId, String text) async {
    if (text.trim().isEmpty) return;
    try {
      socket.sendMessage(chatId: chatId, text: text.trim());
    } catch (_) {}
    // fallback REST if socket is down
    if (socket.socket == null || socket.socket?.connected != true) {
      final res = await api.post('/chats/$chatId/messages', data: {
        'type': 'TEXT',
        'text': text.trim(),
      });
      _onNewMessage(res.data);
    }
  }

  Future<void> sendAttachment(String chatId, MultipartFile file, String type) async {
    final form = FormData.fromMap({'file': file});
    final up = await api.dio.post('/uploads', data: form);
    final att = Map<String, dynamic>.from(up.data);
    if (socket.socket?.connected == true) {
      socket.sendMessage(chatId: chatId, type: type, attachmentId: att['id']);
    } else {
      final res = await api.post('/chats/$chatId/messages', data: {
        'type': type,
        'attachmentId': att['id'],
      });
      _onNewMessage(res.data);
    }
  }

  Future<void> markVisibleRead(String chatId) async {
    final list = messages[chatId] ?? [];
    final mine = me?.id;
    for (final m in list.reversed) {
      if (m.senderId != mine && m.readAt == null) {
        try {
          await api.post('/messages/${m.id}/read');
        } catch (_) {}
      }
    }
    final idx = chats.indexWhere((c) => c.id == chatId);
    if (idx >= 0) {
      chats[idx].unreadCount = 0;
      notifyListeners();
    }
  }

  void openChat(String chatId) {
    activeChatId = chatId;
    socket.joinChat(chatId);
  }

  void closeChat(String chatId) {
    if (activeChatId == chatId) activeChatId = null;
    socket.leaveChat(chatId);
  }

  void _bindSocket() {
    socket.connect(
      onNewMessage: _onNewMessage,
      onDelivered: (raw) {
        final data = Map<String, dynamic>.from(raw);
        _patchMessage(data['chatId'], data['messageId'], delivered: true);
      },
      onRead: (raw) {
        final data = Map<String, dynamic>.from(raw);
        _patchMessage(data['chatId'], data['messageId'], read: true);
      },
      onTypingStart: (raw) {
        final data = Map<String, dynamic>.from(raw);
        if (data['userId'] != me?.id && data['chatId'] == activeChatId) {
          typingUserId = data['userId'];
          notifyListeners();
        }
      },
      onTypingStop: (raw) {
        typingUserId = null;
        notifyListeners();
      },
      onOnline: (raw) {
        _setPeerOnline(raw['userId'], true);
      },
      onOffline: (raw) {
        _setPeerOnline(raw['userId'], false);
      },
    );
  }

  void _onNewMessage(dynamic raw) {
    final msg = MessageModel.fromJson(Map<String, dynamic>.from(raw));
    final list = messages[msg.chatId] ?? [];
    if (list.any((m) => m.id == msg.id)) return;
    messages[msg.chatId] = [...list, msg];
    final idx = chats.indexWhere((c) => c.id == msg.chatId);
    if (idx >= 0) {
      chats[idx].lastMessage = msg;
      if (activeChatId != msg.chatId && msg.senderId != me?.id) {
        chats[idx].unreadCount += 1;
      }
    } else {
      refreshChats();
    }
    notifyListeners();
    if (activeChatId == msg.chatId && msg.senderId != me?.id) {
      api.post('/messages/${msg.id}/read');
    }
  }

  void _patchMessage(String? chatId, String? messageId, {bool delivered = false, bool read = false}) {
    if (chatId == null || messageId == null) return;
    final list = messages[chatId];
    if (list == null) return;
    for (final m in list) {
      if (m.id == messageId) {
        if (delivered) m.deliveredAt ??= DateTime.now();
        if (read) m.readAt ??= DateTime.now();
      }
    }
    notifyListeners();
  }

  void _upsertChat(ChatModel chat) {
    chats = [chat, ...chats.where((c) => c.id != chat.id)];
    notifyListeners();
  }

  void _setPeerOnline(dynamic userId, bool online) {
    for (final c in chats) {
      if (c.peer?.id == userId) {
        // peer is immutable-ish; refresh is enough for last seen
      }
    }
    notifyListeners();
  }

  String _err(DioException e) {
    final data = e.response?.data;
    if (data is Map && data['message'] != null) {
      final m = data['message'];
      if (m is List) return m.join('\n');
      return m.toString();
    }
    return e.message ?? 'Ошибка сети';
  }
}
