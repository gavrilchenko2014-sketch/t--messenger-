import {
  BadRequestException,
  ConflictException,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcryptjs';
import { PrismaService } from '../prisma/prisma.service';
import { LoginDto, RegisterDto } from './dto';
import { publicUser } from '../common/serializers';

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwt: JwtService,
  ) {}

  async register(dto: RegisterDto) {
    if (!dto.email && !dto.phone) {
      throw new BadRequestException('Укажите email или телефон');
    }
    const username = dto.username.trim().toLowerCase();
    const email = dto.email?.trim().toLowerCase() || null;
    const phone = dto.phone?.replace(/\s+/g, '') || null;

    const exists = await this.prisma.user.findFirst({
      where: {
        OR: [
          { username },
          ...(email ? [{ email }] : []),
          ...(phone ? [{ phone }] : []),
        ],
      },
    });
    if (exists) {
      throw new ConflictException('Пользователь с такими данными уже есть');
    }

    const passwordHash = await bcrypt.hash(dto.password, 10);
    const user = await this.prisma.user.create({
      data: {
        username,
        displayName: dto.displayName.trim(),
        email,
        phone,
        passwordHash,
      },
    });
    return this.issue(user);
  }

  async login(dto: LoginDto) {
    const login = dto.login.trim().toLowerCase();
    const user = await this.prisma.user.findFirst({
      where: {
        OR: [{ username: login }, { email: login }, { phone: dto.login.trim() }],
      },
    });
    if (!user) throw new UnauthorizedException('Неверный логин или пароль');
    const ok = await bcrypt.compare(dto.password, user.passwordHash);
    if (!ok) throw new UnauthorizedException('Неверный логин или пароль');
    return this.issue(user);
  }

  private issue(user: any) {
    const accessToken = this.jwt.sign({
      sub: user.id,
      username: user.username,
    });
    return { accessToken, user: publicUser(user) };
  }
}
